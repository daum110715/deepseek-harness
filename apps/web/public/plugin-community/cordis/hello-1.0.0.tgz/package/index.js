"use strict";Object.defineProperty(exports,"__esModule",{value:true});const __dsh$def=(t,k,get)=>Object.defineProperty(t,k,{enumerable:true,configurable:true,get});__dsh$def(exports,"name",()=>name);__dsh$def(exports,"inject",()=>inject);__dsh$def(exports,"apply",()=>apply);/** A normal Cordis plugin No browser-specific SDK is required. */
const name = 'community-hello'
const inject = ['tools']
/** Contribute a tool through the ordinary registry and release it when disabled.
 * @param {import('@deepseek-ai/cordis').Context} ctx Owning plugin context
 */
function apply(ctx) {
  ctx.effect(() => ctx.tools.register({
    name: 'community_echo',
    description: 'Echo text through a community Cordis plugin',
    parameters: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'], additionalProperties: false },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'], additionalProperties: false },
      render: (_args, value) => [{ type: 'text', text: value.text }],
    },
    execute: async args => ({ text: 'Cordis ' + args.text }),
  }), 'community-hello tool')
}
